using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EggHit : MonoBehaviour
{
    private void OnEnable()
    {
        this.GetComponentInParent<shake_dy>().enabled = true;
    }
}
