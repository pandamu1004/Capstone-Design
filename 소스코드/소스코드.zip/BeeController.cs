using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BeeController : MonoBehaviour
{
    private Animator animator;
    public float speed = 3f;
    public float range = 5f;
    public float AR = 1f;

    public GameObject attackRange;
    private Collider2D attack;

    private Vector2 targetPosition;
    private bool isTracking = false;

    public float minX; 
    public float maxX; 
    public float minY; 
    public float maxY; 
    
    private void Start()
    {
        animator = GetComponent<Animator>();
        attack = attackRange.GetComponent<Collider2D>();
        InvokeRepeating("UpdateFlip", 0f, 0.1f);
        SetRandomTargetPosition();
    }

    private void Update()
    {
        if (!isTracking)
        {
            MoveToTargetPosition();
            CheckTargetReached();
            ClampPosition();
        }
        else
        {
            TrackPlayer();
        }
    }

    private void SetRandomTargetPosition()
    {
        float randomX = Random.Range(minX, maxX);
        float randomY = Random.Range(minY, maxY);
        targetPosition = new Vector2(randomX, randomY);
    }

    private void MoveToTargetPosition()
    {
        transform.position = Vector2.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
    }

    private void CheckTargetReached()
    {
        if (Vector2.Distance(transform.position, targetPosition) < 0.1f)
        {
            SetRandomTargetPosition();
        }
    }

    private void TrackPlayer()
    {       

        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            Vector2 direction = player.transform.position - transform.position;
            Vector2 newTargetPosition = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);

            
            if (newTargetPosition.x >= minX && newTargetPosition.x <= maxX && newTargetPosition.y >= minY && newTargetPosition.y <= maxY)
            {
                transform.position = newTargetPosition;

                if (direction.x < 0)
                {
                    transform.localRotation = Quaternion.Euler(0, 0, 0);
                }
                else if (direction.x > 0)
                {
                    transform.localRotation = Quaternion.Euler(0, 180, 0);
                }

                if (Vector2.Distance(transform.position, player.transform.position) <= AR)
                {                   
                    StartCoroutine(DisableCollider(attack));
                }
            }
            else
            {                
                float clampedX = Mathf.Clamp(newTargetPosition.x, minX, maxX);
                float clappedY = Mathf.Clamp(newTargetPosition.y, minY, maxY);

                targetPosition = new Vector2(clampedX, clappedY);
                MoveToTargetPosition();
            }
        }
    }

    public void StartTracking()
    {
        isTracking = true;
    }

    public void StopTracking()
    {
        isTracking = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            StartTracking();
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            StopTracking();
        }
    }

    IEnumerator DisableCollider(Collider2D collider)
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            Vector2 direction = player.transform.position - transform.position;
            if (direction.magnitude <= AR + 3)  // If the player is within attack range
            {
                animator.SetTrigger("Attack");
                collider.enabled = true;
                yield return new WaitForSeconds(0.2f);
                collider.enabled = false;
                animator.SetTrigger("Idle");
                yield return new WaitForSeconds(0.5f);

                
                direction = player.transform.position - transform.position;
                if (direction.magnitude <= AR + 3)
                {
                   
                    StartCoroutine(DisableCollider(attack));
                }
            }
        }
    }

    private void UpdateFlip()
    {
        if (isTracking)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                Vector2 direction = player.transform.position - transform.position;
                if (direction.x < 0)
                {
                    transform.localRotation = Quaternion.Euler(0, 0, 0);
                }
                else if (direction.x > 0)
                {
                    transform.localRotation = Quaternion.Euler(0, 180, 0);
                }
            }
        }
    }

    private void ClampPosition()
    {
        float clampedX = Mathf.Clamp(transform.position.x, minX, maxX);
        float clampedY = Mathf.Clamp(transform.position.y, minY, maxY);
        transform.position = new Vector2(clampedX, clampedY);
    }
}