using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoarController : MonoBehaviour
{
    private Animator animator;
    public float speed = 9f;
    public float trackingSpeed = 15f;
    public float AR = 1f;

    public GameObject attackRange;
    private Collider2D attack;

    private Vector2 targetPosition;
    private bool isTracking = false;


    public float leftLimit = -5f;
    public float rightLimit = 5f;

    private bool movingRight = true;
    private SpriteRenderer spriteRenderer;

    private void Start()
    {
        animator = GetComponent<Animator>();
        attack = attackRange.GetComponent<Collider2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        InvokeRepeating("UpdateFlip", 0f, 0.1f);
        SetPatrolTarget();
    }

    private void Update()
    {
        if (!isTracking)
        {
            Patrol();
        }
        else
        {
            TrackPlayer();
        }
    }

    private void SetPatrolTarget()
    {
        if (movingRight)
            targetPosition = new Vector2(leftLimit, transform.position.y);
        else
            targetPosition = new Vector2(rightLimit, transform.position.y);
        spriteRenderer.flipX = !movingRight;
    }

    private void Patrol()
    {
        transform.position = Vector2.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
        if (Vector2.Distance(transform.position, targetPosition) < 0.1f)
        {
            movingRight = !movingRight;
            spriteRenderer.flipX = !movingRight;
            SetPatrolTarget();
        }
    }

    private void TrackPlayer()
    {
        isTracking = true;
        speed = trackingSpeed;

        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            Vector2 playerPosition = new Vector2(player.transform.position.x, transform.position.y);
            Vector2 direction = playerPosition - (Vector2)transform.position;
            Vector2 newTargetPosition = Vector2.MoveTowards(transform.position, playerPosition, speed * Time.deltaTime);

            if (newTargetPosition.x >= leftLimit && newTargetPosition.x <= rightLimit)
            {
                transform.position = newTargetPosition;

                if (direction.x < 0)
                {
                    spriteRenderer.flipX = false;
                }
                else if (direction.x > 0)
                {
                    spriteRenderer.flipX = true;
                }

                if (direction.magnitude <= AR + 3)
                {
                    isTracking = false;
                    StartCoroutine(DisableCollider(attack));
                }
            }
        }
    }

    public void StartTracking()
    {
        isTracking = true;
    }

    public void StopTracking()
    {
        isTracking = false;
        speed = 9f;
        animator.SetTrigger("Idle"); 
        SetPatrolTarget(); 
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            StartTracking();
            animator.SetTrigger("Run");
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            StopTracking();
        }
    }

    IEnumerator DisableCollider(Collider2D collider)
    {
        animator.SetTrigger("Attack");
        collider.enabled = true;
        yield return new WaitForSeconds(0.1f);
        collider.enabled = false;


        speed = 3f;
        animator.SetTrigger("Idle");
        yield return new WaitForSeconds(1.0f);


        SetPatrolTarget();
    }

    private void UpdateFlip()
    {
        if (isTracking)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                Vector2 direction = player.transform.position - transform.position;
                if (direction.x < 0)
                {
                    spriteRenderer.flipX = false;
                }
                else if (direction.x > 0)
                {
                    spriteRenderer.flipX = true;
                }
            }
        }
    }
}