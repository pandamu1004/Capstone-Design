using UnityEngine;
using System.Collections;
using TMPro;
using UnityEngine.UI;
using System.Collections.Generic;

public class CannonInteraction : MonoBehaviour
{
    public GameObject projectilePrefab;
    public Transform cannonTransform;
    public AudioSource audioSource;


    public float cannonSpeed = 30f;
    public float rotationSpeed = 20f;
    public float minAngle = 0f;
    public float maxAngle = 90f;
    public GameObject cannon;
    public float cooldownTimer = 0f;
    public float cooldownTime = 5f;

    private bool canShoot = true;
    private bool inCol = false;

    private void Update()
    {

        audioSource = GetComponent<AudioSource>();
        if (Input.GetKey(KeyCode.L) && inCol)
        {
            RotateCannon(-rotationSpeed);
        }
        if (Input.GetKey(KeyCode.J) && inCol)
        {
            RotateCannon(rotationSpeed);
        }
        if (canShoot)
        {
            if (Input.GetKeyDown(KeyCode.E) && inCol)
            {
                if (cooldownTimer <= 0f)
                {
                    ShootProjectile();
                    audioSource.Play();
                }
            }
        }
        else
        {
            cooldownTimer -= Time.deltaTime;
            if (cooldownTimer <= 0f)
            {
                canShoot = true;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {

            inCol = true;
}
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            inCol = false;
}
    }

    private void RotateCannon(float rotationAmount)
    {
        float currentAngle = cannon.transform.localEulerAngles.z;
        float targetAngle = Mathf.Clamp(currentAngle + rotationAmount * Time.deltaTime, minAngle, maxAngle);
        cannon.transform.localEulerAngles = new Vector3(0f, 0f, targetAngle);
    }

    private void ShootProjectile()
    {
        if (canShoot)
        {
            GameObject projectile = Instantiate(projectilePrefab, cannonTransform.position, Quaternion.identity);
            Rigidbody2D projectileRigidbody = projectile.GetComponent<Rigidbody2D>();
            if (projectileRigidbody != null)
            {
                Vector2 direction = cannonTransform.up;
                projectileRigidbody.velocity = direction * cannonSpeed;
            }

            canShoot = false;
            cooldownTimer = cooldownTime;
        }
    }
}