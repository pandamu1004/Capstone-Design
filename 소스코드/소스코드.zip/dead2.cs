using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoreMountains.CorgiEngine;

public class dead2 : MonoBehaviour
{
    public MovingPlatform movingplatform;
    private GameObject player;

    private void Start()
    {
        player = GameObject.Find("hive_dy");
    }

    private void Update()
    {
        player = GameObject.Find("hive_dy");
        if (player == null)
        {
            movingplatform.MoveTowardsStart();
            this.enabled = false;
        }
    }
}
