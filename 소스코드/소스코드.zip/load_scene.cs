using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class load_scene : MonoBehaviour
{
    // Start is called before the first frame update
    public void change ()
    {
        SceneManager.LoadScene("main_menu");
    }

  
}
