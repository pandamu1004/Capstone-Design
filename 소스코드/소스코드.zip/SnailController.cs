using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoreMountains.CorgiEngine;

public class SnailController : MonoBehaviour
{
    private Animator animator;
    public float speed = 0f;
    public float range = 2f;
    public float AR = 3f;

    public GameObject attackRange;
    private Collider2D attack;

    private Vector2 targetPosition;
    private bool isTracking = false;

    private void Start()
    {
        animator = GetComponent<Animator>();
        attack = attackRange.GetComponent<Collider2D>();
        InvokeRepeating("UpdateFlip", 0f, 0.1f);
        SetRandomTargetPosition();
    }

    private void Update()
    {
        if (!isTracking)
        {
            MoveToTargetPosition();
            CheckTargetReached();
        }
        else
        {
            TrackPlayer();
        }
    }

    private void SetRandomTargetPosition()
    {
        targetPosition = transform.position + new Vector3(Random.Range(-range, range), Random.Range(-range, range));
    }

    private void MoveToTargetPosition()
    {
        transform.position = Vector2.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
    }

    private void CheckTargetReached()
    {
        if (Vector2.Distance(transform.position, targetPosition) < 0.1f)
        {
            SetRandomTargetPosition();
        }
    }

    private void TrackPlayer()
    {
        isTracking = true;

        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player != null)
        {
            Vector2 direction = player.transform.position - transform.position;
            transform.position = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);

            if (direction.x < 0)
            {
                transform.localRotation = Quaternion.Euler(0, 0, 0);
            }
            else if (direction.x > 0)
            {
                transform.localRotation = Quaternion.Euler(0, 180, 0);
            }

            if (direction.magnitude <= AR + 5)
            {
                isTracking = false;
                StartCoroutine(PlayHideAnimation());
            }
            else
            {
                transform.position = Vector2.MoveTowards(transform.position, player.transform.position, speed * Time.deltaTime);
            }
        }
    }
    public void StartTracking()
    {
        isTracking = true;
    }

    public void StopTracking()
    {
        isTracking = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            StartTracking();
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            StopTracking();
            StartCoroutine(PlayAppearAnimation());
        }
    }

    IEnumerator PlayHideAnimation()
    {
        animator.SetTrigger("Hide");
        yield return new WaitForSeconds(1.0f); // ���� �ִϸ��̼��� ���̿� ���� ����
        animator.SetTrigger("Hidden");
    }

    IEnumerator PlayAppearAnimation()
    {
        animator.SetTrigger("Appear");
        yield return new WaitForSeconds(0.5f); // ��Ÿ���� �ִϸ��̼��� ���̿� ���� ����
        animator.SetTrigger("Idle");
    }

    private void UpdateFlip()
    {
        if (isTracking)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                Vector2 direction = player.transform.position - transform.position;
                if (direction.x < 0)
                {
                    transform.localRotation = Quaternion.Euler(0, 0, 0);
                }
                else if (direction.x > 0)
                {
                    transform.localRotation = Quaternion.Euler(0, 180, 0);
                }
            }
        }
    }
}
