using UnityEngine;

public class CannonBallDestroy : MonoBehaviour
{

    private void Start()
    {
        Invoke("DestroyPrefabAfterDelay", 5f);
    }

    private void DestroyPrefabAfterDelay()
    {
        Destroy(this.gameObject);
    }
}

