using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoreMountains.CorgiEngine;

public class dead : MonoBehaviour
{
    public MovingPlatform movingplatform;
    private GameObject player;

    private void Start()
    {
        player = GameObject.Find("Boar");
    }

    private void Update()
    {
        player = GameObject.Find("Boar");
        if (player == null)
        {
            movingplatform.MoveTowardsStart();
            this.enabled = false;
        }
    }
}
