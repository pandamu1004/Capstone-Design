using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class loadsceneTimer : MonoBehaviour
{
    public float time;

    void Update()
    {
        time += Time.deltaTime;

        if (time > 15f)
        {
            SceneManager.LoadScene("main_menu");
        }
    }
}