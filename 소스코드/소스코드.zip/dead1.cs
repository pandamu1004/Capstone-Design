using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dead1 : MonoBehaviour
{
    private GameObject player;

    private void Start()
    {
        player = GameObject.Find("Boar");
    }
    private void Update()
    {
        GameObject player = GameObject.Find("Boar");
        if (player == null)
        {
            BoxCollider2D boxCollider = GetComponent<BoxCollider2D>();
            if (boxCollider != null)
            {
                Destroy(boxCollider);
            }

            gameObject.layer = LayerMask.NameToLayer("Default");
        }
    }
}